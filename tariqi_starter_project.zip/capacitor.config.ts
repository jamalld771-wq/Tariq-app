import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'sa.tariqi.app',
  appName: 'طريقي',
  webDir: 'web',
  bundledWebRuntime: false
};

export default config;
