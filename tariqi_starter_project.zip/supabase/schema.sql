-- Tariqi starter schema (PostgreSQL / Supabase)
-- Apply only to a new project, then review security policies before production.

create extension if not exists pgcrypto;

create type public.app_role as enum ('rider', 'driver', 'admin');
create type public.trip_status as enum (
  'requested', 'matching', 'driver_assigned', 'driver_arriving',
  'in_progress', 'completed', 'cancelled'
);
create type public.offer_status as enum ('pending', 'accepted', 'rejected', 'expired');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  phone text,
  role public.app_role not null default 'rider',
  created_at timestamptz not null default now()
);

create table public.driver_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  vehicle_make text,
  vehicle_model text,
  vehicle_color text,
  plate_number text,
  is_approved boolean not null default false,
  is_online boolean not null default false,
  last_lat double precision,
  last_lng double precision,
  updated_at timestamptz not null default now()
);

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  rider_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  pickup_label text not null,
  pickup_lat double precision not null,
  pickup_lng double precision not null,
  destination_label text not null,
  destination_lat double precision not null,
  destination_lng double precision not null,
  distance_km numeric(8,2),
  proposed_fare_sar numeric(10,2) not null check (proposed_fare_sar >= 0),
  agreed_fare_sar numeric(10,2) check (agreed_fare_sar >= 0),
  status public.trip_status not null default 'requested',
  payment_status text not null default 'unpaid'
    check (payment_status in ('unpaid','pending','paid','failed','refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.trip_offers (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  driver_id uuid not null references public.profiles(id),
  fare_sar numeric(10,2) not null check (fare_sar >= 0),
  status public.offer_status not null default 'pending',
  created_at timestamptz not null default now(),
  unique (trip_id, driver_id)
);

create table public.trip_ratings (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null unique references public.trips(id) on delete cascade,
  rider_id uuid not null references public.profiles(id),
  driver_id uuid not null references public.profiles(id),
  score int not null check (score between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  provider text not null,
  provider_reference text,
  amount_sar numeric(10,2) not null check (amount_sar >= 0),
  status text not null check (status in ('pending','paid','failed','refunded')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.trips enable row level security;
alter table public.trip_offers enable row level security;
alter table public.trip_ratings enable row level security;
alter table public.payment_events enable row level security;

-- Basic user profile access. Role changes must be handled by trusted admin/server code.
create policy "users read own profile" on public.profiles
  for select to authenticated using (id = auth.uid());
-- Profile edits (especially role changes) should be exposed through a carefully
-- validated server function or restricted column grants. No broad UPDATE policy here.

-- Drivers can read/update only their own driver profile.
create policy "driver reads own driver profile" on public.driver_profiles
  for select to authenticated using (user_id = auth.uid());
-- Do not let drivers update approval status or trusted location fields directly.
-- Use a server function with role/field validation for driver profile changes.

-- Riders can read their trips; assigned drivers can read trips assigned to them.
create policy "trip participants read trips" on public.trips
  for select to authenticated using (rider_id = auth.uid() or driver_id = auth.uid());
-- Create trips only as the current rider. Trip matching/acceptance/status changes should
-- be implemented with server-side functions, not broad client-side UPDATE permissions.
create policy "rider creates own trip" on public.trips
  for insert to authenticated with check (rider_id = auth.uid());

create policy "participants read offers" on public.trip_offers
  for select to authenticated using (
    driver_id = auth.uid() or exists (
      select 1 from public.trips t
      where t.id = trip_id and t.rider_id = auth.uid()
    )
  );
-- Offers should be created/accepted through a server-side function after role/approval checks.

create policy "trip participants read ratings" on public.trip_ratings
  for select to authenticated using (rider_id = auth.uid() or driver_id = auth.uid());
create policy "rider rates own trip" on public.trip_ratings
  for insert to authenticated with check (
    rider_id = auth.uid() and exists (
      select 1 from public.trips t
      where t.id = trip_id and t.rider_id = auth.uid()
        and t.driver_id = driver_id and t.status = 'completed'
    )
  );

-- Payment events are intentionally not client-readable/writable in this starter.
-- Write them from trusted backend/webhook code only.
